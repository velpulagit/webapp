import React, { useState } from 'react';
import CharacterSelect from './components/CharacterSelect';
import GameEngine from './components/GameEngine';
import AnimatedIntro from './components/AnimatedIntro';

export default function App() {
  const [character, setCharacter] = useState(null);
  const [gameStarted, setGameStarted] = useState(false);

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {!character && <CharacterSelect onSelect={setCharacter} />}
      {character && !gameStarted && (
        <AnimatedIntro character={character} onContinue={() => setGameStarted(true)} />
      )}
      {character && gameStarted && <GameEngine character={character} />}
    </div>
  );
}
