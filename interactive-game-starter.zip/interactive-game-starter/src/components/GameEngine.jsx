import React, { useState, useEffect } from 'react';

export default function GameEngine({ character }) {
  const [score, setScore] = useState(0);
  const [position, setPosition] = useState(50);

  useEffect(() => {
    const interval = setInterval(() => {
      setScore((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  function handleMove(direction) {
    setPosition((prev) => Math.max(0, Math.min(prev + direction, 100)));
  }

  return (
    <div className="h-screen flex flex-col items-center justify-center">
      <h2 className="text-2xl mb-4">Score: {score}</h2>
      <div className="relative w-full h-64 border border-white">
        <div
          className="absolute top-1/2 transform -translate-y-1/2 w-16 h-16 text-3xl flex items-center justify-center"
          style={{ left: `${position}%`, transition: 'left 0.3s' }}
        >
          {character === 'Panda' ? '🐼' : '🙈'}
        </div>
      </div>
      <div className="flex gap-6 mt-6">
        <button onClick={() => handleMove(-10)} className="bg-gray-700 px-4 py-2 rounded">⬅️ Left</button>
        <button onClick={() => handleMove(10)} className="bg-gray-700 px-4 py-2 rounded">➡️ Right</button>
      </div>
    </div>
  );
}
