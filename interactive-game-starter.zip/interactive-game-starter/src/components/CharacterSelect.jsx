import React from 'react';

export default function CharacterSelect({ onSelect }) {
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-8">
      <h1 className="text-3xl">Choose Your Hero</h1>
      <div className="flex gap-12">
        <button onClick={() => onSelect('Panda')} className="bg-green-500 px-6 py-3 rounded-xl hover:bg-green-600">🐼 Panda</button>
        <button onClick={() => onSelect('Monkey')} className="bg-yellow-500 px-6 py-3 rounded-xl hover:bg-yellow-600">🙈 Monkey</button>
      </div>
    </div>
  );
}
